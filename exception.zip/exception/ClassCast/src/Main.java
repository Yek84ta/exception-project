public class Main {
    public static void main(String[] args) {

        try {
            Vehicle vehicle = new Car();
            Bike bike = (Bike) vehicle;
        } catch (ClassCastException e) {
            System.out.println("ClassCastException: " + e.getMessage());
        }
    }
}

class Vehicle {}
class Bike extends Vehicle {}
class Car extends Vehicle {}